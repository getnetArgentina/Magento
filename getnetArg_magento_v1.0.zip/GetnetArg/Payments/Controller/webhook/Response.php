<?php
/**
 * Plugin Name:       Magento GetNet
 * Plugin URI:        -
 * Description:       -
 * License:           Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U. 
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0 
 * License URI:       https://opensource.org/licenses/AFL-3.0
 *
 */
namespace GetnetArg\Payments\Controller\Webhook;

use Magento\Framework\Controller\ResultFactory;
use \Magento\Framework\App\Config\ScopeConfigInterface as ScopeConfig;
use \Magento\Quote\Model\QuoteFactory as QuoteFactory;
use Magento\Quote\Model\QuoteIdMask;
use Magento\Quote\Model\QuoteIdMaskFactory;
use \stdClass;
use \Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\Order\Email\Sender\OrderSender;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Sales\Model\Order\Payment\Transaction;
use Magento\Framework\UrlInterface;


class Response extends \Magento\Framework\App\Action\Action
{
    protected $request;
    
    const USER_NOTIF = 'payment/argmagento/user_notif';
    
    const PASW_NOTIF = 'payment/argmagento/pasw_notif';
    
    private $_quote;
    
    private $modelCart;
    
    private $orderRepository;
    
    private $quoteManagement;
    
    private $eventManager;
    
    private $maskedQuoteIdToQuoteId;
    
    protected $_urlInterface;
    
    protected $urlBuilder;
    
    protected $transactionBuilder;
    
    protected $orderSender;
    
    protected $_quoteFactory;
    
    protected $checkoutSession;
    
    protected $customerSession;

    protected $quoteIdMaskFactory;

    protected $_jsonResultFactory;

    protected $quoteRepository;
    
    protected $logger;
    

    public function __construct(
        \Magento\Framework\App\Request\Http $request, 
        \Magento\Framework\App\Action\Context $context,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Quote\Model\QuoteManagement $quoteManagement,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        \Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface $transactionBuilder,
        \Magento\Sales\Model\OrderRepository $orderRepository,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Quote\Model\MaskedQuoteIdToQuoteIdInterface $maskedQuoteIdToQuoteId,
        \Magento\Sales\Model\Order $order,
        QuoteFactory $quoteFactory,
        QuoteIdMaskFactory $quoteIdMaskFactory,
        ScopeConfig $scopeConfig,
        OrderSender $orderSender,
        \Magento\Checkout\Model\Cart $modelCart
    )
    {
        parent::__construct($context);
        $this->request = $request;
        $this->logger = $logger;
        $this->urlBuilder = $context->getUrl();
        $this->_objectManager = $objectManager;
        $this->quoteManagement = $quoteManagement;
        $this->quoteRepository = $quoteRepository;
        $this->orderRepository = $orderRepository;
        $this->maskedQuoteIdToQuoteId = $maskedQuoteIdToQuoteId;
        $this->_quoteFactory = $quoteFactory;
        $this->checkoutSession = $checkoutSession;
        $this->customerSession = $customerSession;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
        $this->transactionBuilder = $transactionBuilder;
        $this->eventManager = $eventManager;
        $this->modelCart = $modelCart;
        $this->scopeConfig = $scopeConfig;
        $this->order = $order;
        $this->orderSender = $orderSender;

    }

    /**
     * 
     * *
     */
    public function execute()
    {
        $responseGetnet = $this->request->getContent();
        
        $this->logger->debug('---------RESULTADO BODY RESPONSE. (responseGetnet) -----------');
        $this->logger->debug($responseGetnet);
        
        $resultRedirect="";
        $ordenItems="";
        $auth = '';
        $message = '';
        $amount= '0';
       
       
        try {
            $jsondata=json_decode($responseGetnet , true);


            $email      = $jsondata["customer"]["email"];
            $method     = $jsondata["payment"]["method"];
            $amount     = $jsondata["payment"]["amount"];
            $currency   = $jsondata["payment"]["currency"];
            $status     = $jsondata["payment"]["result"]["status"];
                            
            $this->logger->debug($amount);
            $this->logger->debug($currency);
            $this->logger->debug($status);
    
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE; 
            $user =    $this->scopeConfig->getValue(self::USER_NOTIF, $storeScope);
            $pasw =    $this->scopeConfig->getValue(self::PASW_NOTIF, $storeScope);
            
            $basicOrigen = 'Basic ' .base64_encode($user . ':' . $pasw);
            $this->logger->debug('credentials origen -->  '.$basicOrigen);

            $originHeader = $this->getRequest()->getHeader('Authorization');
            $this->logger->debug($originHeader);


             ///////////////////////////////////////////////////////////////////////////////
             //////////////////////// Valida autenticaciones ///////////////////////////////
            if($basicOrigen == $originHeader){

                $this->logger->debug("-- validation success --");

              
              $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
              $orderDatamodel = $objectManager->get('Magento\Sales\Model\Order')->getCollection();
              $orderDatamodel = $orderDatamodel->addFieldToFilter('customer_email', ['eq' => $email])->getLastItem();
                           
              $order = $objectManager->create('\Magento\Sales\Model\Order')->load($orderDatamodel->getId());
                    
             $this->logger->debug($status);
            // The message was validated with the signature
            if ($status == 'Authorized'){
                
                $tokenID    = $jsondata["payment"]["payment_method"]["token_id"];
                $paymentID  = $jsondata["payment"]["result"]["payment_id"];
                $authCode   = $jsondata["payment"]["result"]["authorization_code"];
                
                 try{
                    $shippingAmount = $jsondata["shipping"]["shipping_amount"];
                    $this->logger->debug('Shipping cost --> ' . $shippingAmount);
                } catch (\Exception $e) {
                    $shippingAmount = 0;
                }
                
                try{
                    $interes = $jsondata["payment"]["installment"]["interest_rate"];
                    $this->logger->debug('interes --> ' .$interes);
                } catch (\Exception $e) {
                    $interes = 0;
                }
                
                $grandTotal = ($amount + $shippingAmount + $interes) / 100;
                $baseGrandTotal = ($amount) / 100;
                
                $quoteId = $order->getId();
                $this->logger->debug('Total --> '.$order->getGrandTotal().'');
                
                $quote = $this->quoteRepository->get($quoteId);
                $order = $this->orderRepository->get($quoteId);
                   $this->logger->debug('$quote->getId() --> ' .$quote->getId());
                               //////////////////  Init order /////////////////////

                        $this->checkoutSession
                            ->setLastQuoteId($quote->getId())
                            ->setLastSuccessQuoteId($quote->getId())
                            ->clearHelperData();
                            

                                if ($order) {
                                    try {

                                          if (!$this->customerSession->isLoggedIn()) {
                                                $quote->setCheckoutMethod('guest');
                                                $quote->setCustomerIsGuest(true);
                                                $quote->setCustomerEmail($email);
                                            }
                                        

                                        $this->checkoutSession
                                            ->setLastOrderId($order->getId())
                                            ->setLastRealOrderId($order->getIncrementId())
                                            ->setLastOrderStatus($order->getStatus());
                                        $order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING);
                                        $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING);
                                        
                                        $order->setGrandTotal($grandTotal);
                                        $this->orderSender->send($order);
                                        

                                        try{
                                            if($interes !== 0){
                                                $order->addStatusHistoryComment(__('Payment process with ').$method .' , paymentID: ' .$paymentID .' - Authorization Code: ' . $authCode, false);
                                            } else {
                                                $order->addStatusHistoryComment(__('Payment process with ').$method .' , paymentID: ' .$paymentID .' - Authorization Code: ' . $authCode .' - interes : ' . $interes/ 100 , false);
                                            }
                                            $order->save();
                        
                                        } catch (\Exception $e) {
                                             $this->logger->debug('Error Capture');
                                        }
                                        
                                        
                                        $payment = $order->getPayment();
                                        $payment->setTransactionId($tokenID);
                                        $payment->setIsTransactionClosed(0)
                                                ->setTransactionAdditionalInfo(
                                                        $method,
                                                        htmlentities($tokenID)
                                                    );

                                        $payment->setLastTransId($tokenID);
                                        $payment->setIsTransactionClosed(true);
                                        $payment->setShouldCloseParentTransaction(true);
                                        $transaction = $payment->addTransaction(
                                               \Magento\Sales\Model\Order\Payment\Transaction::TYPE_AUTH
                                             );
                                        

                            			$payment->setIsTransactionPending(false);
                            			$payment->setIsTransactionApproved(true);
                            			
                            			$addresss = $objectManager->get('\Magento\Customer\Model\AddressFactory');
                            			$address = $addresss->create();
        			                    $address = $order->getBillingAddress();
        						        $address->setIsDefaultBilling(false)
        								        ->setIsDefaultShipping('1')
        								        ->setSaveInAddressBook('1');
        						        $address->save();
        						        

                                        //for Refund and Capture
                                        $domain = $this->urlBuilder->getRouteUrl('argenmagento');
                                        
                                             $this->logger->debug('Dominio ' .$domain);
        
                                        $payment->setAdditionalInformation('domain', $domain);
                                        $payment->setAdditionalInformation('status', $status);
                                        $payment->setAdditionalInformation('authCode', $authCode);
                                        $payment->setAdditionalInformation('interes', $interes);
                                        $payment->setAdditionalInformation('paymentID', $paymentID);
                                        $payment->setAdditionalInformation('method', 'argenmagento');
                                        
                                            $this->logger->debug('info adicional ');
                                            
                                            
                                        $transaction = $this->transactionBuilder->setPayment($payment)
                            				->setOrder($order)
                            				->setTransactionId($paymentID)
                            				->setAdditionalInformation($payment->getTransactionAdditionalInfo())
                            				->build(Transaction::TYPE_AUTH);


                                        $payment->setParentTransactionId(null);
                                        $payment->save();
                                        
                                        
                                        
                                        //  CREATE INVOICE
                                        $invoice = $objectManager->create('Magento\Sales\Model\Service\InvoiceService')->prepareInvoice($order);
                            			$invoice = $invoice->setTransactionId($payment->getTransactionId())
                                            ->addComment("Invoice created.")
                            				->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
                            
                            			$invoice->setGrandTotal($grandTotal);
                                        $invoice->setBaseGrandTotal($baseGrandTotal);
                            
                                        $invoice->register()->pay();
                            			$invoice->save();
                    
        
                            			// Save the invoice to the order
                            			$transaction = $this->_objectManager->create('Magento\Framework\DB\Transaction')
                            				->addObject($invoice)
                            				->addObject($invoice->getOrder());
                            			$transaction->save();
                            
                            			
                            			$order->addStatusHistoryComment(__('Invoice #%1.', $invoice->getId()) )
                            			->setIsCustomerNotified(true);
                                        
                                        
                                        
                                        $order->save();
                                        $transaction->save();

                                 
                                                 $this->logger->debug('guardo transacción');
                                        
                                        if ($order) {
                                                 $this->logger->debug('-order-');
                                                $this->checkoutSession->setLastOrderId($order->getId())
                                                                   ->setLastRealOrderId($order->getIncrementId())
                                                                   ->setLastOrderStatus($order->getStatus());
                                            }
                                            
                                        $this->messageManager->addSuccessMessage(__('Your payment was processed correctly'));
                        
                                    } catch (\Magento\Framework\Exception\NoSuchEntityException $e) {
                                                $this->messageManager->addErrorMessage(__('Error while saving the transaction'));
                                    }
                                
                                
                                    $cart = $this->modelCart;
                                    $cart->truncate();
                                    $cart->save();

                    
                                    $this->logger->debug('Finished order complete callback.');
                            } // finaliza el $order
                    
            } else { //Error in response
                try{
                    $message = $jsondata["payment"]["result"]["return_message"];
                    
                    $this->messageManager->addErrorMessage(__('Payment declined'));
                    $order->addStatusToHistory('canceled',__('Payment declined') . '--> ' . $message, false);
                    $order->save();
                } catch (\Exception $e) {
                    $this->logger->debug($e);
                }
        
                    $this->logger->debug('Payment Denied');
            }
        } else {
            $this->logger->debug('Validation Authorization error');
        }
            
     } catch (\Exception $e) {
            $this->logger->debug($e);
    }        


  }
 
}