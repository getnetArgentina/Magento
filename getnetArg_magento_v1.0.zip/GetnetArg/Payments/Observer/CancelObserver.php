<?php
/**
 * Plugin Name:       Magento GetNet
 * Plugin URI:        -
 * Description:       -
 * License:           Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U. 
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0 
 * License URI:       https://opensource.org/licenses/AFL-3.0
 *
 */
namespace GetnetArg\Payments\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Sales\Model\Order;

class CancelObserver implements ObserverInterface
{
   const USER_PROCESS = 'payment/argmagento/client_id';
    
   const PASW_PROCESS = 'payment/argmagento/secret_id';
    
   const TEST_ENV = 'payment/argmagento/test_environment';
    
   protected $messageManager;
    
   protected $order;
   
   private $remoteAddress;
   
   protected $logger;

    public function __construct(
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Framework\HTTP\PhpEnvironment\RemoteAddress $remoteAddress,
        \Psr\Log\LoggerInterface $logger,
        Order $order
    )
    {
        $this->messageManager = $messageManager;
        $this->remoteAddress = $remoteAddress;
        $this->order = $order;
        $this->logger = $logger;
    }
    
    
    
   /**
   * Sets order status to pending
   * @param \Magento\Framework\Event\Observer $observer
   * @return void
   */
    public function execute(\Magento\Framework\Event\Observer $observer){
          $this->logger->debug('--------------------------------------------');
          $this->logger->debug('----Cancel observer');
      
          $order = $observer->getEvent()->getOrder();
    
          $state = $order->getState();
      
      
          //////////////////////////////////////////////////////
          //////// validate date for Cancel or Refund //////////
          //////////////////////////////////////////////////////
          $dateTrx = date_create($order->getCreatedAt());
          $dateTrx = date_format($dateTrx,"d/m/Y");
          $sysdate = date("d/m/Y");
          $this->logger->debug($dateTrx);
    
          
          $payment = $order->getPayment();
          $amount = $order->getGrandTotal();
          $shippingAmount = $order->getShippingAmount();
          $currency = $order->getOrderCurrencyCode();

/*          
      try{
            $interes = $payment->getAdditionalInformation('interes');
            
        } catch (\Exception $e) {
            $interes = 0;
            $this->logger->debug('Error get interes');
        }
        
         $amount = ($amount * 100) + $interes;
         $this->logger->debug('Interes. ' . $interes);
*/         
          $this->logger->debug('amount Total = ' .$amount);
          $this->logger->debug('Shipping = ' .$shippingAmount);

    
            $paymentID = $payment->getAdditionalInformation('paymentID');
            
                    if($dateTrx == $sysdate){ //Same day cancel
                        $this->logger->debug('Init Cancel');
                         $action = 'cancellation';
                         $jsonBody = '';
        
                     } else { //Different day refund
                         $this->logger->debug('Init Refund');
                         
                         $amount = ($amount * 100);
                         
                         $action = 'refund';
                         $jsonBody = '{
                                        "amount": '.$amount.'
                                      }';
                     }



                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                
                $clienId = \Magento\Framework\App\ObjectManager::getInstance()
                        ->get(\Magento\Framework\App\Config\ScopeConfigInterface::class)
                        ->getValue(self::USER_PROCESS,\Magento\Store\Model\ScopeInterface::SCOPE_STORE,);
        
                $secret = \Magento\Framework\App\ObjectManager::getInstance()
                        ->get(\Magento\Framework\App\Config\ScopeConfigInterface::class)
                        ->getValue(self::PASW_PROCESS,\Magento\Store\Model\ScopeInterface::SCOPE_STORE,);
                        
                 $testEnv = \Magento\Framework\App\ObjectManager::getInstance()
                    ->get(\Magento\Framework\App\Config\ScopeConfigInterface::class)
                    ->getValue(self::TEST_ENV,\Magento\Store\Model\ScopeInterface::SCOPE_STORE,);        
                        
                
                 /////////GET TOKEN /////////                
                $configHelper = $objectManager->create('GetnetArg\Payments\Model\ClientWS');
                $token = $configHelper->getToken($clienId, $secret, $testEnv);
                

                ///send POST
                $jsondata = $configHelper->getPostOperation($token, $jsonBody, $testEnv, $action, $paymentID);
                    $this->logger->debug('before decode');
                    
                $result=json_decode($jsondata, true); 


            if (str_contains($jsondata, 'payment_id')) {
                    $newpayment_id = $result["payment_id"];
                    $newStatus     = $result["status"];
                    $newDate       = $result["transaction_datetime"];
                    $authCode      = $result["authorization_code"];
                    $authPaymentID = $result["authorization_payment_id"];
                    $olderPaymentID = $result["generated_by"];
                    
                             $this->logger->debug('New Status --> ' . $newStatus);
                    
                    if ($newStatus == 'Refunded' || $newStatus == 'Cancelled') {
                             $message = __('New Payment ID >> ') .$newpayment_id .', '. __('Status >> ') .$newStatus .', '. __('Authorization Code >> ') .$authCode .' --> ' .$newDate;
                             $statusOperation = 'success';
                             $order->addStatusToHistory('canceled',__('Successful operation ') .' --> '. $message, false);
                             $order->save();
        
                    } else {
                        throw new \Magento\Framework\Exception\LocalizedException(__("Fail to Cancel"));
        
                    }
                    
            } else if (str_contains($jsondata, 'message')) {
                     $message = $result["message"];
                     $statusOperation = 'fail';
                     $order->addStatusToHistory('processing', __('Operation Fails '). ' --> ' . $message, false);
                     $order->save();
                     
                            $this->logger->debug('message --> ' . $message);
                 
            } else {
                     $statusOperation = 'fail';
                     $order->addStatusToHistory('processing', __("Fail to Cancel"), false);
                     $order->save();
            }
            
            
            // Error handled with response message
            if ($statusOperation == 'fail' ) {
                 $this->logger->debug('In exception-');
               throw new \Magento\Framework\Exception\LocalizedException(__("Fail to Cancel"));
             }

    $this->logger->debug('--Cancel fin--');
    }
    
}