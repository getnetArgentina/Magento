<?php
/**
 * Plugin Name:       Magento GetNet
 * Plugin URI:        -
 * Description:       -
 * License:           Copyright © 2023 PagoNxt Merchant Solutions S.L. and Santander España Merchant Services, Entidad de Pago, S.L.U. 
 * You may not use this file except in compliance with the License which is available here https://opensource.org/licenses/AFL-3.0 
 * License URI:       https://opensource.org/licenses/AFL-3.0
 *
 */
namespace GetnetArg\Payments\Observer;

use Magento\Framework\Event\ObserverInterface;
use GetnetArg\Payments\Model\Directpost;

class AfterOrderPlaceObserver implements ObserverInterface
{
  /**
   * Sets order status to pending
   * @param \Magento\Framework\Event\Observer $observer
   * @return void
   */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        /** @var \Magento\Sales\Model\Order $order */
        $order = $observer->getEvent()->getOrder();
        $payment = $order->getPayment();
        if ($payment->getMethod() == Directpost::METHOD_CODE) {
            $order->setState('pending_payment');
            $order->setStatus('pending_payment');
        }
    }
}
