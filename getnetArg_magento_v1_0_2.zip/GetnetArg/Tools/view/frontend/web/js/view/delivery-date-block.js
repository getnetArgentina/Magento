define([
    'jquery',
    'ko',
    'uiComponent'
], function ($, ko, Component) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'GetnetArg_Tools/delivery-date-block'
        },
        initialize: function () {
            this._super();

            return this;
        }
    });
});
