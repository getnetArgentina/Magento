var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'GetnetArg_Tools/js/model/shipping-save-processor/default'
        }
    }
};