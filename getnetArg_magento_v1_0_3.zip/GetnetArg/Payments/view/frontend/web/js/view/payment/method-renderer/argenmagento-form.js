/*browser:true*/
/*global define*/

define(
	    [
	        'ko',
	        'jquery',
	        'Magento_Checkout/js/view/payment/default',
	        'GetnetArg_Payments/js/action/set-payment-method-action'
	    ],
    function (ko, $, Component, setPaymentMethodAction) {
        'use strict';
        return Component.extend({
            defaults: {
                redirectAfterPlaceOrder: false,
                logo: 'GetnetArg_Payments/images/icon_getnet_mini.png',
                template: 'GetnetArg_Payments/payment/argenmagento-form.html'
            },
            
            getLogoUrl: function() {
                return require.toUrl(this.logo);
            },

            afterPlaceOrder: function () {
                setPaymentMethodAction(this.messageContainer);
                return false;
            }
        });        
        
    }
);
